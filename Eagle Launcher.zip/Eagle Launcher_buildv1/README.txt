EagleLauncher

EagleLauncher is a launcher created by White Eagle Games Studio.
It allows you to manage your games, contact the studio, and change language or other settings.

🖥️ Requirements
Windows 10 or newer
.NET 8.0 Runtime (if not included in the build)
⚙️ Installation
Download the EagleLauncher.exe file
Double-click to run it

🎮 Features
Games Tab – Displays your games (currently empty)
Contact Tab – Links to the Discord server and email
Options Tab – Allows you to switch between Polish and English languages

📫 Contact
Discord: Join here
Email: whiteeaglegamesstudio@gmail.com

⚖️ License
This project is the property of White Eagle Games Studio.
Unauthorized copying, modification, or redistribution is prohibited.